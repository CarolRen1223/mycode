# Lesson 3.4: Make Classes
# Mini-Project: Movies Website

# In this file, you will define instances of the class Movie defined
# in media.py. After you follow along with Kunal, make some instances
# of your own!

# After you run this code, open the file fresh_tomatoes.html to
# see your webpage!

import media
import fresh_tomatoes

lust_caution=media.Movie("Lust,Caution","Ang Lee's Lust, Caution is a tense, sensual and beautifully-shot espionage film.","https://resizing.flixster.com/6gi4bEU0nsCFh9jLJdL66wF8BMg=/206x305/v1.bTsxMTI5NzQ4OTtqOzE3Mjc1OzEyMDA7MTUzNjsyMDQ4","https://www.youtube.com/watch?v=p0o3yNnbCR4")

spirited_away=media.Movie("Spirited Away","Spirited Away is a dazzling, enchanting, and gorgeously drawn fairy tale that will leave viewers a little more curious and fascinated by the world around them.","https://resizing.flixster.com/N_skVM4QpmbmaAl1GFeQ7Z7WcDg=/206x305/v1.bTsxMTIwNzQzNztqOzE3Mjc0OzEyMDA7MTUzNjsyMDQ4","https://www.youtube.com/watch?v=ByXuk9QqQkk")

the_shawshank_redemption=media.Movie("The Shawshank Redemption","The Shawshank Redemption is an uplifting, deeply satisfying prison drama with sensitive direction and fine performances.","https://resizing.flixster.com/HgRjxWLRqGr1P11gaJ07WGl9F6U=/206x305/v1.bTsxMTE2NjcyNztqOzE3Mjc0OzEyMDA7ODAwOzEyMDA","https://www.youtube.com/watch?v=6hB3S9bIaco")


movies = [lust_caution,spirited_away,the_shawshank_redemption]
fresh_tomatoes.open_movies_page(movies)
